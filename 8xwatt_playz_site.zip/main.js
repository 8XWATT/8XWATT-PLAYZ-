
// This file should be replaced with the React build output.
document.getElementById('root').innerHTML = '<h1>8XWATT PLAYZ React App Coming Soon</h1>';
